export const name = 'sanjin';
